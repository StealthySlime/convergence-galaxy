---
name: Bug report
about: Report a reproducible problem
title: "[Bug] "
labels: bug
---

## Description

## Steps to reproduce

1.
2.
3.

## Expected behavior

## Server environment

- Garry's Mod branch:
- Operating system:
- SAM installed:
- SWU installed:

## Errors

```text
Paste errors here.
```

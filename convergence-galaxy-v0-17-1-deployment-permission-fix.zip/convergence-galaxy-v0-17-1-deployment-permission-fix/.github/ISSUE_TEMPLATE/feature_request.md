---
name: Feature request
about: Suggest a feature or integration
title: "[Feature] "
labels: enhancement
---

## Feature

## Use case

## Proposed behavior

## Dependencies or integrations

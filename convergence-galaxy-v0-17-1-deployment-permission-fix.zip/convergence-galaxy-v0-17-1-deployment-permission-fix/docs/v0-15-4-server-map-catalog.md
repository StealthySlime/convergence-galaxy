# Version 0.15.4 — Authoritative Server Map Catalog

The deployment selector no longer scans maps on the client.

Both the Operations and Director buttons now request an authoritative catalog
from the server. The server returns:

- configured regions when the operation planet has configured regions
- every mounted server BSP map when no regions are configured

The catalog is compressed before transmission.

## Operations button

The Operations tab and Director page now use the same request function.
An already-active deployment may reopen the selector to repair or update a map
chosen by an older build.

## Commands

```text
convergence_server_map_count
convergence_deployment_maps <planet>
```

`convergence_server_map_count` prints the actual server-side mounted BSP count.

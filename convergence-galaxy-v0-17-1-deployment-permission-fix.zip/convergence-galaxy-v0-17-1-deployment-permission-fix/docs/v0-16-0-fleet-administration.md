# Version 0.16.0 — Fleet Administration

## Director Fleet Manager

The new Director-only Fleet Manager supports:

- creating fleets
- renaming fleets
- changing fleet strength
- ordering campaign-time travel
- instantly relocating a fleet as a GM
- deleting fleets

Setting fleet strength to zero uses the existing destruction/archive system and
removes the fleet from the active galaxy map.

## SAM commands

```text
!convergencefleets
!fleetmanager
```

Both open the Director directly to the Fleet Manager.

## Main server map

The canonical main server map is now configured as:

```text
rp_stardestroyer_v2_7_inf
```

It is treated as a main/orbit map, keeping encounter NPC spawning disabled by
default.

## Test

```text
convergence_fleet_admin_test
```

Expected:

```text
Result: 5/5 passed
```

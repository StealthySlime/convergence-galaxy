# Version 0.17.0 — Fleet Logistics Foundation

## Persistent logistics fields

Fleets now persist:

- commander
- home planet
- experience
- morale
- supplies
- composition
- battle statistics

Existing fleets migrate safely and retain their previous strength as a legacy
combat rating until a composition is assigned.

## Combat rating

A fleet's derived combat rating uses:

- fleet composition
- experience rank
- morale
- supplies

Updating logistics synchronizes the existing `strength` field so autonomous
fleet battles continue working without a combat-system rewrite.

## Planet Inspector

Selecting a planet now displays **Stationed Fleets** before Available
Operations. Each fleet shows:

- faction
- combat rating
- experience rank
- commander
- morale
- supplies

Directors may click a stationed fleet card to open Fleet Manager.

## Test

```text
convergence_fleet_logistics_test
```

Expected:

```text
Result: 6/6 passed
```

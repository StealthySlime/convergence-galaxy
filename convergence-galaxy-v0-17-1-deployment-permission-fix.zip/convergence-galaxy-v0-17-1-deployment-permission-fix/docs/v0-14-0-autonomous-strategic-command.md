# Version 0.14.0 — Autonomous Strategic Command

The Galactic AI think cycle now has an explicit lifecycle.

A cycle immediately receives a cycle ID and increments the think counter before
performing any subsystem work. This prevents a successful or partially
successful forced think from still reporting `Think count: 0`.

Each cycle records these stages:

```text
cycle_started
intelligence_refresh
faction_discovery
friendly_<faction>
enemy_<faction>
cycle_complete
```

Every faction decision records:

- cycle ID
- action
- target planet
- success/failure
- full reason or underlying order error
- campaign timestamp

## Commands

```text
convergence_ai_think
convergence_ai_status
convergence_ai_test
```

The AI test now validates the actual cycle:

```text
thinkCompleted          PASS
thinkCountIncremented   PASS
cycleRecorded           PASS
Result: 9/9 passed
```

The Director's Galactic AI tab now shows the latest cycle, its duration, every
processing stage, and each faction's final decision.

# Version 0.15.0 — Autonomous Galaxy

## Autonomous fleet travel

Fleet orders already initiate campaign-time travel. The galaxy map continues
to display live movement and ETA using each fleet's departure and arrival
campaign timestamps.

## Autonomous orbital battles

When friendly and enemy fleets occupy the same planet, the Fleet Battle
service now:

- applies proportional damage to every fleet
- persists new fleet strength
- destroys fleets at zero strength
- changes planetary influence
- changes planetary stability
- creates a player-selectable Fleet Battle operation when forces are closely
  matched
- publishes campaign history and Galactic News
- continues resolving on simulation ticks without pausing player deployments

## Commands

```text
convergence_fleet_battle_status
convergence_fleet_battle_tick <planet>
convergence_fleet_battle_test
```

Expected:

```text
Fleet battles: PASS
Result: 5/5 passed
```

To perform a live battle test, create opposing fleets at the same planet, then
run:

```text
convergence_fleet_battle_tick reach
convergence_fleet_battle_status
```

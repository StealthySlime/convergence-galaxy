# Version 0.15.2 — Deployment Map Selector

Clicking **Deploy Players** now always opens a real dropdown selector.

The selector obtains maps from:

1. the operation's Director snapshot
2. the operation planet's snapshot regions as a fallback

It supports both array-based and ID-keyed region tables.

The GM must select a configured GMod map before deployment can start. When a
planet has no regions, deployment is blocked with a clear error instead of
silently deploying without a map.

## Diagnostics

```text
convergence_deployment_maps reach
```

Expected:

```text
orbit            Reach Orbit                  map=rp_venator
surface          Reach Surface                map=rp_reach
Regions: 2
```

## Fleet destruction test correction

The previous test incorrectly expected Reach to contain zero fleets after
destroying the temporary test fleet. It now verifies only that the temporary
fleet itself is absent, allowing other legitimate fleets to remain at Reach.

# Version 0.17.1 — Deployment Permission Fix

The deployment map network handler incorrectly called:

```lua
Convergence.Permissions.CanDirect(ply)
```

That function does not exist. It now uses the established Director permission:

```lua
Convergence.Permissions.CanOpenDirector(ply)
```

After restarting, click **Deploy Players** from both the Director page and the
Operations tab. Both should request and display the server map catalog without
a Lua error.

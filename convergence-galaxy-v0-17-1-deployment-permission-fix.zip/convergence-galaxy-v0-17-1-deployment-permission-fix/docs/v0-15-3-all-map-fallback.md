# Version 0.15.3 — All-Map Deployment Fallback

When a planet has configured regions, Deploy Players continues to restrict the
GM to those approved region/map choices.

When a planet has no configured regions, the selector now lists every mounted
`maps/*.bsp` map available to the client. The list includes a search box.

The server independently validates the selected map with:

```lua
file.Exists("maps/" .. mapName .. ".bsp", "GAME")
```

This prevents clients from submitting nonexistent map names.

The selected fallback map is locked into the deployment snapshot as:

```text
regionID: custom_map
customMap: true
map: <selected map>
```

Convergence prepares the map choice but does not run `changelevel`; the GM
still controls when the server changes maps.

## Diagnostic

```text
convergence_deployment_maps <planet>
```

For a planet without configured regions:

```text
Regions: 0
Fallback: all mounted maps are selectable (<count> maps).
```

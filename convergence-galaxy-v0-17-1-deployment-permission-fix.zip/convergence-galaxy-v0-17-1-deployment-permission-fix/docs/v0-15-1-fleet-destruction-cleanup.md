# Version 0.15.1 — Fleet Destruction Cleanup

When fleet strength reaches zero:

- the fleet is marked `destroyed` in SQLite
- it is removed from the active fleet cache immediately
- it disappears from the galaxy map and Fleet page
- it can no longer receive AI orders
- it no longer participates in fleet battles
- its final snapshot remains in the destroyed-fleet archive for history and
  diagnostics

Destroyed rows are also separated from active fleets during server startup, so
they do not reappear after a restart.

## Fleet creation commands

```text
convergence_fleet_create <faction> <planet> <strength> <name>
convergence_fleet_move <fleet_id> <planet> <campaign_hours>
convergence_fleet_delete <fleet_id>
convergence_fleets
convergence_fleets_destroyed
```

Example:

```text
convergence_fleet_create republic reach 1000 Republic Test Fleet
convergence_fleet_create covenant reach 900 Covenant Test Fleet
```

## Test

```text
convergence_fleet_destruction_test
```

Expected:

```text
Result: 5/5 passed
```

Convergence.Config = Convergence.Config or {}

local Config = Convergence.Config

Config.Debug = false
Config.DefaultStability = 100
Config.MinimumStability = 0
Config.MaximumStability = 100

Config.Clock = {
    TickInterval = 5,
    SecondsPerCampaignHour = 60,
    StartingDay = 1,
    StartingHour = 0,
    AutoStart = true,
    SaveEveryTicks = 12
}

Config.Simulation = {
    MaxQueuedActionsPerTick = 100,
    MaxProcessorMilliseconds = 25,
    HistoryLimit = 100,
    StopOnProcessorError = false
}

Config.World = {
    PlayerTaskForceName = "Galactic Defense Coalition Task Force",
    DefaultPlanetID = "coruscant",
    ProtectNPCSpawning = true,

    SWU = {
        -- Raw SWU travel estimates are converted into a cinematic duration.
        -- With the defaults, ordinary jumps take roughly 45 seconds to 3 minutes.
        MinimumHyperspaceSeconds = 45,
        MaximumHyperspaceSeconds = 180,
        EstimateDivisor = 60,

        -- A large non-hyperspace position change is treated as a GM GOTO.
        TeleportDeltaThreshold = 50,
        PlanetArrivalRadius = 8
    },

    MainMaps = {
        ["rp_stardestroyer_v2_7_inf"] = true,
        ["rp_venator"] = true,
        ["rp_star_destroyer"] = true
    },

    DefaultMainMap = "rp_stardestroyer_v2_7_inf"
}

Config.Campaign = {
    HistorySnapshotLimit = 250,
    NewsSnapshotLimit = 100,
    DailyReportIntervalDays = 1,
    IntelligenceThreatWarning = 55,
    IntelligenceThreatCritical = 80,
    AIEnabled = true,
    AIThinkIntervalSeconds = 120,
    AIOperationCooldownSeconds = 900,
    AIFleetTravelHours = 6,
    AIMinimumOperationThreat = 28,
    AIFriendlyReinforceThreat = 35,
    AIEnemyAttackOpportunity = 34,
    FleetBattleIntervalTicks = 2,
    FleetBattleDamageMinimum = 0.08,
    FleetBattleDamageMaximum = 0.22,
    FleetBattleOperationThreshold = 0.25,
    PlanetCaptureInfluenceLead = 20,
    PlanetCaptureStabilityThreshold = 20,
    NotificationDurationSeconds = 8,
    NotifyPlayersOfFleetArrivals = true,
    NotifyPlayersOfTaskForceTravel = true,
    AIBattleMinimumSeconds = 3600,
    AIBattleMaximumSeconds = 7200,
    MajorBattleMaximumSeconds = 10800,
    MaximumGMExtensionSeconds = 14400,
    DefaultVictoryStability = 10,
    DefaultDefeatStability = -15,
    DefaultInfluenceChange = 15,
    SingleActiveDeployment = true,
    ServerID = "primary"
}

Config.Galaxy = {
    MinZoom = 0.65,
    MaxZoom = 2.5,
    DefaultZoom = 1,
    ZoomSmoothing = 10,
    PanSmoothing = 14,
    NodeRadius = 13,
    ScanlineSpeed = 18,
    GridDriftSpeed = 4,
    HyperlanePulseSpeed = 110,
    Routes = {
        {"coruscant", "tatooine"},
        {"coruscant", "reach"},
        {"reach", "tatooine"}
    }
}

Config.StabilityStates = {
    {id = "collapse", name = "Collapse", minimum = 0, maximum = 0},
    {id = "convergence", name = "Convergence", minimum = 1, maximum = 20},
    {id = "critical", name = "Critical", minimum = 21, maximum = 40},
    {id = "unstable", name = "Unstable", minimum = 41, maximum = 60},
    {id = "strained", name = "Strained", minimum = 61, maximum = 80},
    {id = "stable", name = "Stable", minimum = 81, maximum = 100}
}

Config.Planets = {
    {
        id = "coruscant",
        name = "Coruscant",
        defaultStability = 100,
        galaxy = {x = 0.24, y = 0.58, sector = "Core Worlds"},
        swu = {name = "Coruscant", pos = Vector(0, 0, 0)},
        regions = {
            {id = "orbit", name = "Coruscant Orbit", map = "rp_venator"},
            {id = "surface", name = "Coruscant Surface", map = "rp_coruscant"}
        }
    },
    {
        id = "tatooine",
        name = "Tatooine",
        defaultStability = 75,
        galaxy = {x = 0.77, y = 0.64, sector = "Outer Rim"},
        swu = {name = "Tatooine", pos = Vector(3.2, -1.4, 0)},
        regions = {
            {id = "orbit", name = "Tatooine Orbit", map = "rp_venator"},
            {id = "mos_eisley", name = "Mos Eisley", map = "rp_tatooine"}
        }
    },
    {
        id = "reach",
        name = "Reach",
        defaultStability = 60,
        galaxy = {x = 0.56, y = 0.27, sector = "Epsilon Eridani"},
        swu = {name = "Reach", pos = Vector(220, 180, 0)},
        regions = {
            {id = "orbit", name = "Reach Orbit", map = "rp_venator"},
            {id = "surface", name = "Reach Surface", map = "rp_reach"}
        }
    }
}

function Convergence.ValidateConfig()
    local errors = {}

    if not isnumber(Config.MinimumStability) or not isnumber(Config.MaximumStability) then
        errors[#errors + 1] = "Stability bounds must be numeric."
    elseif Config.MinimumStability >= Config.MaximumStability then
        errors[#errors + 1] = "Minimum stability must be lower than maximum stability."
    end

    if not istable(Config.Clock) then
        errors[#errors + 1] = "Clock configuration must be a table."
    end

    if not istable(Config.Simulation) then
        errors[#errors + 1] = "Simulation configuration must be a table."
    end

    if not istable(Config.Galaxy) then
        errors[#errors + 1] = "Galaxy configuration must be a table."
    end

    if not istable(Config.StabilityStates) or #Config.StabilityStates == 0 then
        errors[#errors + 1] = "At least one stability state must be configured."
    end

    local seenPlanets = {}

    for index, planet in ipairs(Config.Planets or {}) do
        local id = Convergence.NormalizeID(planet.id)

        if id == "" then
            errors[#errors + 1] = "Planet #" .. index .. " has no valid ID."
        elseif seenPlanets[id] then
            errors[#errors + 1] = "Duplicate planet ID: " .. id
        else
            seenPlanets[id] = true
        end
    end

    Convergence.Log.MinimumLevel = Config.Debug
        and Convergence.Constants.LOG_LEVELS.DEBUG
        or Convergence.Constants.LOG_LEVELS.INFO

    return #errors == 0, errors
end

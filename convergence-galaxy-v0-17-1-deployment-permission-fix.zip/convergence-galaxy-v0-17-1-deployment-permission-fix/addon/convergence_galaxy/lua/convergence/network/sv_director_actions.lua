util.AddNetworkString("Convergence.Director.Action")
util.AddNetworkString("Convergence.Director.Result")

local ACTION_CREATE = "create_operation"
local ACTION_DEPLOY = "deploy"
local ACTION_RESOLVE = "resolve"
local ACTION_EXTEND = "extend"
local ACTION_ENCOUNTER_START = "encounter_start"
local ACTION_ENCOUNTER_END = "encounter_end"
local ACTION_PREPARE_REGION = "prepare_region"
local ACTION_FLEET_CREATE = "fleet_create"
local ACTION_FLEET_MOVE = "fleet_move"
local ACTION_FLEET_RELOCATE = "fleet_relocate"
local ACTION_FLEET_RENAME = "fleet_rename"
local ACTION_FLEET_STRENGTH = "fleet_strength"
local ACTION_FLEET_DELETE = "fleet_delete"

local function sendResult(ply, success, message)
    net.Start("Convergence.Director.Result")
    net.WriteBool(success == true)
    net.WriteString(tostring(message or ""))
    net.Send(ply)
end

local function context(ply, reason)
    return {
        actor = ply,
        source = "director_ui",
        reason = reason
    }
end

local function readStringList()
    local count = math.min(net.ReadUInt(8), 16)
    local result = {}

    for _ = 1, count do
        result[#result + 1] = Convergence.NormalizeID(net.ReadString())
    end

    return result
end

net.Receive("Convergence.Director.Action", function(_, ply)
    if not Convergence.Permissions.CanManageCampaign(ply) then
        sendResult(ply, false, "Campaign-management permission denied.")
        return
    end

    local action = Convergence.NormalizeID(net.ReadString())

    if action == ACTION_CREATE then
        local name = string.Trim(net.ReadString())
        local planetID = Convergence.NormalizeID(net.ReadString())
        local regionID = Convergence.NormalizeID(net.ReadString())
        local eventType = Convergence.NormalizeID(net.ReadString())
        local difficulty = Convergence.NormalizeID(net.ReadString())
        local priority = Convergence.NormalizeID(net.ReadString())
        local briefing = string.Trim(net.ReadString())
        local friendly = readStringList()
        local enemy = readStringList()

        local success, result, message =
            Convergence.CampaignEvents.Create({
                name = name,
                planetID = planetID,
                regionID = regionID ~= "" and regionID or nil,
                eventType = eventType ~= "" and eventType or "battle",
                difficulty = difficulty ~= "" and difficulty or "standard",
                priority = priority ~= "" and priority or "normal",
                briefing = briefing,
                friendlyFactions = #friendly > 0
                    and friendly
                    or {"republic", "unsc"},
                enemyFactions = enemy,
                aiProgressActive = true,
                status = "available"
            }, context(ply, "GM created operation through Director UI."))

        sendResult(
            ply,
            success,
            success
                and ("Created operation: " .. result.name)
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_DEPLOY then
        local eventID = Convergence.NormalizeID(net.ReadString())
        local selectedRegionID = Convergence.NormalizeID(net.ReadString())
        local selectedMap = string.Trim(net.ReadString() or "")

        local success, result, message = Convergence.Deployments.Start(
            eventID,
            context(ply, "GM deployed players through Director UI."),
            selectedRegionID,
            selectedMap
        )

        sendResult(
            ply,
            success,
            success
                and string.format(
                    "Player deployment started: %s%s",
                    result.eventID,
                    result.lockedSnapshot
                        and result.lockedSnapshot.map
                        and (" | Prepared map: " .. result.lockedSnapshot.map)
                        or ""
                )
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_RESOLVE then
        local outcome = Convergence.NormalizeID(net.ReadString())
        local notes = string.Trim(net.ReadString())
        local success, result, message = Convergence.Deployments.End(
            outcome,
            notes,
            context(ply, "GM resolved deployment through Director UI.")
        )

        sendResult(
            ply,
            success,
            success
                and ("Deployment resolved: " .. result.name)
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_EXTEND then
        local eventID = Convergence.NormalizeID(net.ReadString())
        local seconds = math.floor(net.ReadUInt(32))
        local success, result, message =
            Convergence.CampaignEvents.Extend(eventID, seconds)

        sendResult(
            ply,
            success,
            success
                and ("Extended operation: " .. result.name)
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_ENCOUNTER_START then
        Convergence.World.SetEncounterActive(true, context(
            ply,
            "GM activated encounter through Director UI."
        ))
        sendResult(ply, true, "Encounter activated; NPC spawning is now allowed.")
        return
    end

    if action == ACTION_ENCOUNTER_END then
        Convergence.World.SetEncounterActive(false, context(
            ply,
            "GM ended encounter through Director UI."
        ))
        sendResult(ply, true, "Encounter ended; NPC spawning is disabled.")
        return
    end


    if action == ACTION_FLEET_CREATE then
        local name = string.Trim(net.ReadString())
        local factionID = Convergence.NormalizeID(net.ReadString())
        local planetID = Convergence.NormalizeID(net.ReadString())
        local strength = math.Clamp(net.ReadUInt(32), 1, 1000000)

        local success, result, message = Convergence.Fleets.Create(
            name,
            factionID,
            planetID,
            strength,
            context(ply, "GM created fleet through Director UI.")
        )

        sendResult(
            ply,
            success,
            success
                and ("Created fleet: " .. result.name)
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_FLEET_MOVE then
        local fleetID = Convergence.NormalizeID(net.ReadString())
        local planetID = Convergence.NormalizeID(net.ReadString())
        local campaignHours = math.max(net.ReadFloat(), 0.01)

        local success, result, message = Convergence.Fleets.Move(
            fleetID,
            planetID,
            campaignHours,
            context(ply, "GM ordered fleet movement through Director UI.")
        )

        sendResult(
            ply,
            success,
            success
                and string.format(
                    "%s is traveling to %s.",
                    result.name,
                    result.destinationPlanetID
                )
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_FLEET_RELOCATE then
        local fleetID = Convergence.NormalizeID(net.ReadString())
        local planetID = Convergence.NormalizeID(net.ReadString())

        local success, result, message = Convergence.Fleets.Relocate(
            fleetID,
            planetID,
            context(ply, "GM relocated fleet through Director UI.")
        )

        sendResult(
            ply,
            success,
            success
                and string.format(
                    "%s relocated to %s.",
                    result.name,
                    result.currentPlanetID
                )
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_FLEET_RENAME then
        local fleetID = Convergence.NormalizeID(net.ReadString())
        local newName = string.Trim(net.ReadString())

        local success, result, message = Convergence.Fleets.Rename(
            fleetID,
            newName,
            context(ply, "GM renamed fleet through Director UI.")
        )

        sendResult(
            ply,
            success,
            success
                and ("Fleet renamed: " .. result.name)
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_FLEET_STRENGTH then
        local fleetID = Convergence.NormalizeID(net.ReadString())
        local strength = math.Clamp(net.ReadUInt(32), 0, 1000000)

        local success, result, message = Convergence.Fleets.SetStrength(
            fleetID,
            strength,
            context(ply, "GM changed fleet strength through Director UI.")
        )

        sendResult(
            ply,
            success,
            success
                and string.format(
                    "%s strength set to %d.",
                    result.name,
                    result.strength
                )
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_FLEET_DELETE then
        local fleetID = Convergence.NormalizeID(net.ReadString())

        local success, result, message = Convergence.Fleets.Delete(
            fleetID,
            context(ply, "GM deleted fleet through Director UI.")
        )

        sendResult(
            ply,
            success,
            success
                and "Fleet deleted."
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    if action == ACTION_PREPARE_REGION then
        local eventID = Convergence.NormalizeID(net.ReadString())
        local event = Convergence.CampaignEvents.Get(eventID)

        if not event then
            sendResult(ply, false, "Unknown campaign operation.")
            return
        end

        local world = Convergence.World.GetState()
        local currentPlanetID = Convergence.NormalizeID(
            world.currentPlanetID or ""
        )

        if currentPlanetID ~= event.planetID then
            local currentPlanet =
                Convergence.PlanetService.Get(currentPlanetID)
            local targetPlanet =
                Convergence.PlanetService.Get(event.planetID)

            sendResult(
                ply,
                false,
                string.format(
                    "Travel to %s before preparing this deployment. Current location: %s.",
                    targetPlanet and targetPlanet:GetName() or event.planetID,
                    currentPlanet and currentPlanet:GetName() or (
                        currentPlanetID ~= "" and currentPlanetID or "Unknown"
                    )
                )
            )
            return
        end

        if not event.regionID or event.regionID == "" then
            sendResult(
                ply,
                false,
                "This operation does not have a configured region."
            )
            return
        end

        local success, result, message =
            Convergence.World.PrepareMapTransition(event.regionID)

        sendResult(
            ply,
            success,
            success
                and string.format(
                    "Prepared %s. GM may change to %s.",
                    result.name,
                    result.map
                )
                or string.format("[%s] %s", tostring(result), tostring(message))
        )
        return
    end

    sendResult(ply, false, "Unknown Director action.")
end)

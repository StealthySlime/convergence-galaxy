Convergence.DeploymentMapsClient =
    Convergence.DeploymentMapsClient or {}

local Client = Convergence.DeploymentMapsClient

Client.PendingEventID = nil
Client.RequestedAt = 0

function Client.Request(eventID)
    eventID = Convergence.NormalizeID(eventID)

    if eventID == "" then
        chat.AddText(
            Color(240, 90, 90),
            "[Convergence] Invalid operation ID."
        )
        return
    end

    Client.PendingEventID = eventID
    Client.RequestedAt = CurTime()

    net.Start("Convergence.DeploymentMaps.Request")
    net.WriteString(eventID)
    net.SendToServer()
end

net.Receive("Convergence.DeploymentMaps.Response", function()
    local length = net.ReadUInt(32)
    local compressed = length > 0 and net.ReadData(length) or ""
    local decoded = compressed ~= ""
        and util.Decompress(compressed)
        or nil
    local payload = decoded and util.JSONToTable(decoded) or nil

    if not istable(payload) then
        chat.AddText(
            Color(240, 90, 90),
            "[Convergence] Invalid deployment-map response."
        )
        return
    end

    if payload.success ~= true then
        chat.AddText(
            Color(240, 90, 90),
            "[Convergence] ",
            Color(235, 235, 235),
            tostring(payload.message or "Unable to load deployment maps.")
        )
        return
    end

    Convergence.UI.OpenDeploymentMapSelector(
        payload.eventID,
        payload.event,
        payload
    )
end)

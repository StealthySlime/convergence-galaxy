util.AddNetworkString("Convergence.DeploymentMaps.Request")
util.AddNetworkString("Convergence.DeploymentMaps.Response")

local function normalizeMapName(filename)
    return string.StripExtension(
        string.GetFileFromFilename(tostring(filename or ""))
    )
end

local function mountedMaps()
    local result = {}
    local seen = {}

    for _, filename in ipairs(file.Find("maps/*.bsp", "GAME") or {}) do
        local mapName = normalizeMapName(filename)

        if mapName ~= "" and not seen[mapName] then
            seen[mapName] = true
            result[#result + 1] = mapName
        end
    end

    table.sort(result, function(left, right)
        return string.lower(left) < string.lower(right)
    end)

    return result
end

local function configuredRegions(planetID)
    local result = {}

    for _, region in ipairs(
        Convergence.World.GetRegions(planetID) or {}
    ) do
        result[#result + 1] = {
            id = region.id,
            name = region.name,
            map = region.map
        }
    end

    return result
end

local function sendPayload(ply, payload)
    local encoded = util.TableToJSON(payload, false) or "{}"
    local compressed = util.Compress(encoded) or ""

    net.Start("Convergence.DeploymentMaps.Response")
    net.WriteUInt(#compressed, 32)

    if #compressed > 0 then
        net.WriteData(compressed, #compressed)
    end

    net.Send(ply)
end

net.Receive("Convergence.DeploymentMaps.Request", function(_, ply)
    if not IsValid(ply)
        or not Convergence.Permissions.CanOpenDirector(ply) then
        return
    end

    local eventID = Convergence.NormalizeID(net.ReadString())
    local event = Convergence.CampaignEvents.Get(eventID)

    if not event then
        sendPayload(ply, {
            success = false,
            eventID = eventID,
            message = "Unknown campaign operation."
        })
        return
    end

    local regions = configuredRegions(event.planetID)
    local maps = {}

    if #regions == 0 then
        maps = mountedMaps()
    end

    sendPayload(ply, {
        success = true,
        eventID = event.id,
        event = {
            id = event.id,
            name = event.name,
            planetID = event.planetID,
            regionID = event.regionID,
            status = event.status,
            playerControlled = event.playerControlled == true
        },
        configured = #regions > 0,
        regions = regions,
        maps = maps
    })
end)

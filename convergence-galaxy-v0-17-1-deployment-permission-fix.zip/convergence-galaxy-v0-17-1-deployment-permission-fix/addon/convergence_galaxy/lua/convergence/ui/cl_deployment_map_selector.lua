Convergence.UI = Convergence.UI or {}

local UI = Convergence.UI

function UI.RequestDeploymentMapSelector(eventID)
    if not Convergence.DeploymentMapsClient then
        chat.AddText(
            Color(240, 90, 90),
            "[Convergence] Deployment map client is unavailable."
        )
        return
    end

    Convergence.DeploymentMapsClient.Request(eventID)
end

function UI.OpenDeploymentMapSelector(eventID, event, catalog)
    if not event or not istable(catalog) then
        chat.AddText(
            Color(240, 90, 90),
            "[Convergence] Deployment map data is unavailable."
        )
        return
    end

    local entries = {}
    local usingAllMaps = catalog.configured ~= true

    if usingAllMaps then
        for _, mapName in ipairs(catalog.maps or {}) do
            entries[#entries + 1] = {
                id = "",
                name = mapName,
                map = mapName,
                allMapsFallback = true
            }
        end
    else
        for _, region in ipairs(catalog.regions or {}) do
            entries[#entries + 1] = {
                id = Convergence.NormalizeID(region.id or ""),
                name = tostring(region.name or region.id or "Unnamed Region"),
                map = tostring(region.map or ""),
                allMapsFallback = false
            }
        end
    end

    if #entries == 0 then
        Derma_Message(
            usingAllMaps
                and "The server did not report any mounted BSP maps."
                or "This planet has no valid configured deployment maps.",
            "Deployment Maps Unavailable",
            "CLOSE"
        )
        return
    end

    local frame = vgui.Create("DFrame")
    frame:SetSize(720, 410)
    frame:Center()
    frame:SetTitle(
        "Select Deployment Map — "
        .. tostring(event.name or eventID)
    )
    frame:SetDeleteOnClose(true)
    frame:MakePopup()
    frame:MoveToFront()

    local description = vgui.Create("DLabel", frame)
    description:Dock(TOP)
    description:SetTall(72)
    description:DockMargin(14, 10, 14, 6)
    description:SetWrap(true)
    description:SetText(
        usingAllMaps
            and (
                "No deployment regions are configured for this planet. "
                .. "Choose from the maps mounted on the server."
            )
            or (
                "Choose one of this planet's configured deployment regions."
            )
    )

    local form = vgui.Create("DPanel", frame)
    form:Dock(FILL)
    form:DockMargin(14, 4, 14, 8)
    form.Paint = nil

    local planetLabel = vgui.Create("DLabel", form)
    planetLabel:Dock(TOP)
    planetLabel:SetTall(28)
    planetLabel:SetText(
        "Planet: " .. tostring(event.planetID or "Unknown")
    )

    local sourceLabel = vgui.Create("DLabel", form)
    sourceLabel:Dock(TOP)
    sourceLabel:SetTall(28)
    sourceLabel:SetText(
        usingAllMaps
            and ("Server map catalog — " .. tostring(#entries) .. " maps")
            or ("Configured regions — " .. tostring(#entries))
    )

    local search = vgui.Create("DTextEntry", form)
    search:Dock(TOP)
    search:SetTall(36)
    search:SetPlaceholderText("Search maps...")

    local dropdown = vgui.Create("DComboBox", form)
    dropdown:Dock(TOP)
    dropdown:SetTall(42)
    dropdown:SetSortItems(false)
    dropdown:SetValue("Select a map...")

    local selected = nil
    local lastSelectedMap = nil

    local selectedInfo = vgui.Create("DLabel", form)
    selectedInfo:Dock(TOP)
    selectedInfo:SetTall(64)
    selectedInfo:DockMargin(0, 8, 0, 0)
    selectedInfo:SetWrap(true)
    selectedInfo:SetText("Select a deployment map.")

    local function populate(filter)
        dropdown:Clear()
        selected = nil

        filter = string.lower(string.Trim(tostring(filter or "")))
        local visible = 0
        local autoSelect = nil

        for _, entry in ipairs(entries) do
            local searchable = string.lower(
                tostring(entry.name) .. " " .. tostring(entry.map)
            )

            if filter == ""
                or string.find(searchable, filter, 1, true) then
                visible = visible + 1

                dropdown:AddChoice(
                    usingAllMaps
                        and entry.map
                        or (entry.name .. "  —  " .. entry.map),
                    table.Copy(entry),
                    false
                )

                if lastSelectedMap == entry.map then
                    autoSelect = visible
                elseif not usingAllMaps
                    and event.regionID
                    and Convergence.NormalizeID(event.regionID) == entry.id then
                    autoSelect = visible
                end
            end
        end

        dropdown:SetValue(
            visible > 0
                and ("Select a map... (" .. visible .. ")")
                or "No matching maps"
        )

        if autoSelect then
            dropdown:ChooseOptionID(autoSelect)
        elseif visible == 1 then
            dropdown:ChooseOptionID(1)
        end
    end

    dropdown.OnSelect = function(_, _, _, data)
        if not istable(data) then
            return
        end

        selected = data
        lastSelectedMap = data.map

        selectedInfo:SetText(string.format(
            "%s\nGMod map: %s",
            data.allMapsFallback
                and "Server map selection"
                or ("Region: " .. tostring(data.name)),
            tostring(data.map)
        ))
    end

    search.OnValueChange = function(_, value)
        populate(value)
    end

    populate("")

    local buttons = vgui.Create("DPanel", frame)
    buttons:Dock(BOTTOM)
    buttons:SetTall(58)
    buttons:DockMargin(14, 0, 14, 12)
    buttons.Paint = nil

    local cancel = UI.Components.CreateButton(
        buttons,
        "CANCEL",
        function()
            frame:Close()
        end,
        true
    )
    cancel:Dock(LEFT)
    cancel:SetWide(180)

    local deploy = UI.Components.CreateButton(
        buttons,
        event.playerControlled and "UPDATE MAP" or "PREPARE & DEPLOY",
        function()
            if not selected or selected.map == "" then
                chat.AddText(
                    Color(240, 90, 90),
                    "[Convergence] Select a deployment map first."
                )
                return
            end

            Convergence.Director.Send("deploy", function()
                net.WriteString(eventID)
                net.WriteString(selected.id or "")
                net.WriteString(selected.map)
            end)

            frame:Close()
        end
    )
    deploy:Dock(RIGHT)
    deploy:SetWide(220)
end

Convergence.UI.RegisterModule({
    id = "fleet_manager",
    name = "Fleet Manager",
    order = 52,
    adminOnly = true,
    directorOnly = true,

    create = function(self, parent)
        local Components = Convergence.UI.Components
        local Theme = Convergence.UI.Theme
        local data = Convergence.GalaxyData or {}
        local root = vgui.Create("DPanel", parent)
        root:Dock(FILL)
        root.Paint = nil

        local toolbar = vgui.Create("DPanel", root)
        toolbar:Dock(TOP)
        toolbar:SetTall(58)
        toolbar:DockMargin(12, 12, 12, 0)
        toolbar.Paint = nil

        local scroll = vgui.Create("DScrollPanel", root)
        scroll:Dock(FILL)

        local function sortedChoices(source, labelCallback)
            local values = {}

            for id, value in pairs(source or {}) do
                values[#values + 1] = {
                    id = id,
                    label = labelCallback(id, value)
                }
            end

            table.sort(values, function(left, right)
                return left.label < right.label
            end)

            return values
        end

        local function createFleetDialog()
            local frame = vgui.Create("DFrame")
            frame:SetSize(560, 430)
            frame:Center()
            frame:SetTitle("Create Fleet")
            frame:MakePopup()

            local form = vgui.Create("DPanel", frame)
            form:Dock(FILL)
            form:DockMargin(14, 12, 14, 12)
            form.Paint = nil

            local name = vgui.Create("DTextEntry", form)
            name:Dock(TOP)
            name:SetTall(38)
            name:SetPlaceholderText("Fleet name")

            local faction = vgui.Create("DComboBox", form)
            faction:Dock(TOP)
            faction:SetTall(38)
            faction:DockMargin(0, 10, 0, 0)
            faction:SetValue("Select faction...")

            for _, choice in ipairs(sortedChoices(
                data.factions,
                function(id, value)
                    return tostring(value.name or id)
                end
            )) do
                faction:AddChoice(choice.label, choice.id)
            end

            local planet = vgui.Create("DComboBox", form)
            planet:Dock(TOP)
            planet:SetTall(38)
            planet:DockMargin(0, 10, 0, 0)
            planet:SetValue("Select starting planet...")

            for _, choice in ipairs(sortedChoices(
                data.planets,
                function(id, value)
                    return tostring(
                        value.state and value.state.name or id
                    )
                end
            )) do
                planet:AddChoice(choice.label, choice.id)
            end

            local strength = vgui.Create("DNumberWang", form)
            strength:Dock(TOP)
            strength:SetTall(38)
            strength:DockMargin(0, 10, 0, 0)
            strength:SetMinMax(1, 1000000)
            strength:SetValue(1000)

            local create = Components.CreateButton(
                form,
                "CREATE FLEET",
                function()
                    local _, factionID = faction:GetSelected()
                    local _, planetID = planet:GetSelected()

                    if string.Trim(name:GetValue()) == ""
                        or not factionID
                        or not planetID then
                        chat.AddText(
                            Color(240, 90, 90),
                            "[Convergence] Complete all fleet fields."
                        )
                        return
                    end

                    Convergence.Director.Send("fleet_create", function()
                        net.WriteString(name:GetValue())
                        net.WriteString(factionID)
                        net.WriteString(planetID)
                        net.WriteUInt(
                            math.max(math.floor(strength:GetValue()), 1),
                            32
                        )
                    end)

                    frame:Close()
                end
            )
            create:Dock(BOTTOM)
            create:SetTall(46)
        end

        local createButton = Components.CreateButton(
            toolbar,
            "CREATE FLEET",
            createFleetDialog
        )
        createButton:Dock(LEFT)
        createButton:SetWide(190)

        local refreshButton = Components.CreateButton(
            toolbar,
            "REFRESH",
            function()
                RunConsoleCommand("convergence_ui_refresh")
            end
        )
        refreshButton:Dock(RIGHT)
        refreshButton:SetWide(150)

        if table.IsEmpty(data.fleets or {}) then
            Components.CreateEmptyState(
                scroll,
                "No Active Fleets",
                "Create a fleet to begin managing strategic assets."
            )
            return root
        end

        local function openEditDialog(id, fleet)
            local frame = vgui.Create("DFrame")
            frame:SetSize(600, 560)
            frame:Center()
            frame:SetTitle("Manage Fleet — " .. tostring(fleet.name or id))
            frame:MakePopup()

            local form = vgui.Create("DPanel", frame)
            form:Dock(FILL)
            form:DockMargin(14, 12, 14, 12)
            form.Paint = nil

            local rename = vgui.Create("DTextEntry", form)
            rename:Dock(TOP)
            rename:SetTall(38)
            rename:SetValue(tostring(fleet.name or id))

            local renameButton = Components.CreateButton(
                form,
                "RENAME",
                function()
                    Convergence.Director.Send("fleet_rename", function()
                        net.WriteString(id)
                        net.WriteString(rename:GetValue())
                    end)
                end
            )
            renameButton:Dock(TOP)
            renameButton:SetTall(40)
            renameButton:DockMargin(0, 6, 0, 0)

            local strength = vgui.Create("DNumberWang", form)
            strength:Dock(TOP)
            strength:SetTall(38)
            strength:DockMargin(0, 14, 0, 0)
            strength:SetMinMax(0, 1000000)
            strength:SetValue(tonumber(fleet.strength) or 0)

            local strengthButton = Components.CreateButton(
                form,
                "SET STRENGTH",
                function()
                    Convergence.Director.Send("fleet_strength", function()
                        net.WriteString(id)
                        net.WriteUInt(
                            math.max(math.floor(strength:GetValue()), 0),
                            32
                        )
                    end)
                end
            )
            strengthButton:Dock(TOP)
            strengthButton:SetTall(40)
            strengthButton:DockMargin(0, 6, 0, 0)

            local planet = vgui.Create("DComboBox", form)
            planet:Dock(TOP)
            planet:SetTall(38)
            planet:DockMargin(0, 14, 0, 0)
            planet:SetValue("Select destination...")

            for _, choice in ipairs(sortedChoices(
                data.planets,
                function(planetID, value)
                    return tostring(
                        value.state and value.state.name or planetID
                    )
                end
            )) do
                planet:AddChoice(choice.label, choice.id)
            end

            local hours = vgui.Create("DNumberWang", form)
            hours:Dock(TOP)
            hours:SetTall(38)
            hours:DockMargin(0, 8, 0, 0)
            hours:SetMinMax(0.01, 1000)
            hours:SetDecimals(2)
            hours:SetValue(6)

            local moveButton = Components.CreateButton(
                form,
                "ORDER TRAVEL",
                function()
                    local _, planetID = planet:GetSelected()

                    if not planetID then
                        return
                    end

                    Convergence.Director.Send("fleet_move", function()
                        net.WriteString(id)
                        net.WriteString(planetID)
                        net.WriteFloat(math.max(hours:GetValue(), 0.01))
                    end)
                end
            )
            moveButton:Dock(TOP)
            moveButton:SetTall(40)
            moveButton:DockMargin(0, 6, 0, 0)

            local relocateButton = Components.CreateButton(
                form,
                "GM RELOCATE INSTANTLY",
                function()
                    local _, planetID = planet:GetSelected()

                    if not planetID then
                        return
                    end

                    Convergence.Director.Send("fleet_relocate", function()
                        net.WriteString(id)
                        net.WriteString(planetID)
                    end)
                end,
                true
            )
            relocateButton:Dock(TOP)
            relocateButton:SetTall(40)
            relocateButton:DockMargin(0, 6, 0, 0)

            local deleteButton = Components.CreateButton(
                form,
                "DELETE FLEET",
                function()
                    Derma_Query(
                        "Permanently delete " .. tostring(fleet.name) .. "?",
                        "Delete Fleet",
                        "DELETE",
                        function()
                            Convergence.Director.Send("fleet_delete", function()
                                net.WriteString(id)
                            end)
                            frame:Close()
                        end,
                        "CANCEL"
                    )
                end,
                true
            )
            deleteButton:Dock(BOTTOM)
            deleteButton:SetTall(44)
        end

        for id, fleet in SortedPairs(data.fleets or {}) do
            if fleet.status ~= "destroyed"
                and (tonumber(fleet.strength) or 0) > 0 then
                local faction = (data.factions or {})[fleet.factionID]
                local card = Components.CreateCard(
                    scroll,
                    tostring(fleet.name or id)
                )
                card:Dock(TOP)
                card:SetTall(345)
                card:DockMargin(12, 12, 12, 0)

                Components.CreateStatRow(card, "ID", id)
                Components.CreateStatRow(
                    card,
                    "Faction",
                    faction and faction.name or fleet.factionID
                )
                Components.CreateStatRow(
                    card,
                    "Strength",
                    tostring(fleet.strength or 0)
                )
                Components.CreateStatRow(
                    card,
                    "Status",
                    string.upper(tostring(fleet.status or "unknown"))
                )
                Components.CreateStatRow(
                    card,
                    "Current Planet",
                    tostring(fleet.currentPlanetID or "Unknown")
                )
                Components.CreateStatRow(
                    card,
                    "Destination",
                    tostring(fleet.destinationPlanetID or "None")
                )
                Components.CreateStatRow(
                    card,
                    "Commander",
                    string.Trim(tostring(fleet.commander or "")) ~= ""
                        and fleet.commander
                        or "Unassigned"
                )
                Components.CreateStatRow(
                    card,
                    "Experience",
                    string.format(
                        "%s (%d XP)",
                        tostring(fleet.experienceRank or "Recruit"),
                        tonumber(fleet.experience) or 0
                    )
                )
                Components.CreateStatRow(
                    card,
                    "Morale / Supplies",
                    string.format(
                        "%.0f%% / %.0f%%",
                        tonumber(fleet.morale) or 100,
                        tonumber(fleet.supplies) or 100
                    )
                )

                local manage = Components.CreateButton(
                    card,
                    "MANAGE",
                    function()
                        openEditDialog(id, fleet)
                    end
                )
                manage:Dock(BOTTOM)
                manage:SetTall(42)
            end
        end

        return root
    end
})

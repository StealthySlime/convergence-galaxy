Convergence.Simulation.RegisterProcessor({
    id = "fleet_battles",
    name = "Autonomous Fleet Battle Processor",
    priority = 70,
    runEveryTicks = math.max(
        tonumber(
            Convergence.Config.Campaign.FleetBattleIntervalTicks
        ) or 2,
        1
    ),

    process = function(self, tickContext)
        return {
            processedBattles = Convergence.FleetBattles.Process()
        }
    end
})

# Changelog

## 0.17.1 — Deployment Permission Fix

### Fixed

- Server map catalog request calling the nonexistent
  `Convergence.Permissions.CanDirect` function.
- Deploy Players map selector failing with a Lua error before the server could
  return its map catalog.

### Changed

- Deployment map requests now use the existing
  `Convergence.Permissions.CanOpenDirector` permission check.
- Addon version increased to `0.17.1`.

## 0.17.0 — Fleet Logistics Foundation

### Added

- Persistent fleet commander, homeworld, experience, morale, supplies,
  composition, and statistics fields.
- Fleet combat-rating calculator.
- Fleet experience ranks.
- Fleet logistics update API.
- Stationed-fleet lookup service.
- Stationed Fleets section in the Planet Inspector.
- Fleet logistics details in Fleet Manager.
- `convergence_fleet_logistics_test`.

### Changed

- Database target schema increased to 10.
- Logistics changes synchronize the legacy fleet strength used by autonomous
  battles.
- Addon version increased to `0.17.0`.

## 0.16.0 — Fleet Administration

### Added

- Director-only Fleet Manager.
- Fleet create, rename, strength, travel, relocate, and delete actions.
- Fleet rename and GM relocation service methods.
- SAM commands `!convergencefleets` and `!fleetmanager`.
- `convergence_fleet_admin_test`.
- Canonical main-map configuration for `rp_stardestroyer_v2_7_inf`.

### Changed

- Addon version increased to `0.16.0`.

## 0.15.4 — Authoritative Server Map Catalog

### Fixed

- Deployment fallback reading the client's mounted maps instead of the
  server's maps.
- Deploy Players in the Operations tab using a separate, unreliable path.
- Operations button doing nothing for an existing same-operation deployment.
- Older active deployments being unable to select or repair their map.

### Added

- Compressed server-to-client deployment map catalog.
- Shared authoritative request path for Operations and Director.
- Active deployment map update/repair support.
- `convergence_server_map_count`.

### Changed

- Addon version increased to `0.15.4`.

## 0.15.3 — All-Map Deployment Fallback

### Added

- Searchable list of every mounted BSP map when a planet has no configured
  deployment regions.
- Server-side validation of arbitrary fallback map selections.
- Custom-map deployment snapshots.
- Custom-map preparation support in the World service.

### Changed

- Configured planets remain restricted to their configured maps.
- Unconfigured planets no longer block player deployment.
- Addon version increased to `0.15.3`.

## 0.15.2 — Deployment Map Selector

### Fixed

- Deploy Players not visibly presenting map choices.
- Deployment selector depending only on `event.regions`.
- Selector failing when regions were stored in an ID-keyed table.
- Deployments being permitted without a configured map.
- Fleet destruction test failing when unrelated fleets remained at Reach.

### Added

- Real `DComboBox` deployment-map dropdown.
- Planet snapshot fallback for deployment regions.
- Selected region and GMod map preview.
- `convergence_deployment_maps <planet>` diagnostics.

### Changed

- Addon version increased to `0.15.2`.

## 0.15.1 — Fleet Destruction Cleanup

### Fixed

- Destroyed fleets remaining visible on the galaxy map.
- Zero-strength fleets remaining in the active fleet cache.
- Destroyed fleets reappearing after a server restart.
- Completed orbital battles remaining in the active-battle display until the
  next simulation pass.

### Added

- Destroyed-fleet archive.
- `convergence_fleets_destroyed`.
- `convergence_fleet_destruction_test`.
- Defensive destroyed-fleet filtering in snapshots, the galaxy renderer, and
  the Fleet page.

### Changed

- Addon version increased to `0.15.1`.

## 0.15.0 — Autonomous Galaxy

### Added

- Autonomous orbital fleet battles.
- Persistent fleet-strength damage and destruction.
- Proportional damage distribution across fleets.
- Fleet-battle influence and stability effects.
- Automatic Fleet Battle operation generation.
- Fleet-battle history and Galactic News reports.
- Director fleet-battle snapshot data.
- Fleet Battle diagnostics, test, and manual tick commands.

### Changed

- Fleet orders and campaign-time travel now feed directly into autonomous
  battles on arrival.
- Addon version increased to `0.15.0`.

## 0.14.0 — Autonomous Strategic Command

### Added

- Explicit AI think-cycle IDs and stage tracking.
- Per-cycle decision snapshots.
- Think-cycle history.
- Detailed fleet-order and operation-generation failure reasons.
- Last-cycle stages in the Director Galactic AI monitor.
- Think-counter and cycle-record validation in `convergence_ai_test`.

### Fixed

- Forced AI think appearing to complete while the think counter remained zero.
- AI status lacking visibility into partial or failed processing stages.
- Generic decision messages hiding the underlying Fleet Order or Operation
  Generator error.

### Changed

- Think count advances at cycle start.
- Addon version increased to `0.14.0`.

## 0.13.0 — Living Galaxy AI

### Added

- Explainable Threat Engine 2.0.
- Autonomous friendly reinforcement decisions.
- Autonomous hostile invasion decisions.
- AI-generated campaign operations.
- AI operation cooldown and duplication safeguards.
- Galactic AI Director monitor.
- AI decisions in Galactic News and Campaign History.
- Faction AI status, toggle, force-think, and test commands.

### Changed

- Strategic threat now includes neighboring hostile pressure, strategic value,
  operation severity, and fleet-strength advantage.
- Addon version increased to `0.13.0`.

## 0.12.0 — Core Service Lifecycle

### Added

- Deterministic core-service bootstrap.
- Registration for legacy Planet, Faction, Influence, Stability, Fleet,
  Simulation, Clock, Alliance, and Fleet Order services.
- Core dependency validation before Living Galaxy initialization.
- Lifecycle status, test, and repair commands.
- Lifecycle-ready event and hook.
- Additional Service Facade aliases.

### Fixed

- Service Facade reporting older working systems as unavailable.
- Strategic Intelligence receiving no planets from the facade.
- Living Galaxy test failing `intelligencePlanets`.
- Highest Threat remaining empty because Intelligence had no registered
  Planet Service.

### Changed

- Intelligence now waits for the core lifecycle.
- Addon version increased to `0.12.0`.

## 0.11.1 — Service Cleanup and Intelligence Polish

### Fixed

- Strategic Intelligence calling a missing `GetEnemyIDs` function.
- Intelligence directly depending on multiple subsystem internals.

### Added

- Central service facade.
- Friendly, enemy, and neutral faction APIs.
- Friendly and enemy influence aggregation.
- Cached intelligence refresh.
- Fleet-strength contribution to threat scoring.
- Highest-threat summary on the Director dashboard.
- `convergence_service_status` diagnostics.

### Changed

- Addon version increased to `0.11.1`.

## 0.11.0 — Living Galaxy

### Added

- Galactic News Network service and UI.
- Automatic operation, battle, and fleet news.
- Automatic daily campaign reports.
- Director-only strategic intelligence assessments.
- Threat scoring and recommended responses.
- Strategic-control halos on galaxy-map planets.
- Living Galaxy diagnostics and tests.

### Changed

- Addon version increased to `0.11.0`.

## 0.10.0 — Campaign History and Notifications

### Added

- Persistent campaign-history database and service.
- Campaign History UI tab with category filters.
- Automatic history entries for operations, deployments, fleets, travel, and
  encounters.
- Queued Galactic Command HUD notifications.
- History and notification diagnostics and tests.
- Database migration 9.

### Changed

- Addon version increased to `0.10.0`.
- Database schema increased to `9`.

## 0.9.11 — SWU Navigation Reset

### Fixed

- Completed Reach jumps leaving Reach selected permanently.
- Navigation consoles refusing to select another planet after hyperspace exit.
- External hyperspace speed modifier carrying into the next route.
- Completed-jump loading, target, progress, and estimate state remaining set.

### Added

- Automatic navigation-computer reset after every arrival.
- Admin recovery command `convergence_swu_reset_navigation`.

### Changed

- Addon version increased to `0.9.11`.

## 0.9.10 — SWU Arrival and Registry Fix

### Fixed

- Numeric `1`, `2`, and `3` planet IDs caused by iterating the planet array as
  an ID-keyed table.
- Reach using an impractically large SWU coordinate.
- Client Ship Position/GOTO lists not receiving Convergence planets.
- SWU builds remaining in hyperspace after the practical timer elapsed.
- SWU physical position not being reconciled to the selected planet on arrival.

### Added

- Client command `convergence_swu_client_sync`.
- Emergency admin command `convergence_swu_force_arrival`.
- Hyperspace-exit compatibility fallback.

### Changed

- Addon version increased to `0.9.10`.

## 0.9.9 — Deployment Map and SWU Planet Registration

### Added

- Deployment map-selection dialog.
- Server-validated deployment region selection.
- Selected map and region stored in the deployment snapshot.
- Automatic region preparation when deployment starts.
- Synchronization into discoverable SWU planet registries.
- Automatic mapping generation for future configured planets.
- `convergence_swu_planet_status` diagnostics.

### Fixed

- Configured planets such as Reach not appearing in SWU Ship Position/GOTO.
- Deploy Players starting without choosing the destination event map.

### Changed

- Addon version increased to `0.9.9`.

## 0.9.8 — Location-Gated Deployments

### Added

- Server-side planet validation for player deployments.
- Server-side planet validation for operation-region preparation.
- Disabled Prepare Region and Deploy Players controls when the task force is
  not at the operation planet.
- Location-specific tooltips explaining why controls are unavailable.

### Changed

- Prepare Region now sends an operation ID and resolves its region securely on
  the server.
- Addon version increased to `0.9.8`.

## 0.9.7 — Operation Workflow

### Added

- Clickable planet-operation entries.
- Planet-filtered Operations page navigation.
- Priority-colored operation cards.
- Prepare Region and Deploy Players controls on selected operations.
- Resolved-operation filters.
- Resolution date and time.
- Faction-colored influence effects in the archive.

### Changed

- Addon version increased to `0.9.7`.

## 0.9.6

- Added operation badges, planet operation listings, and resolved archive.
